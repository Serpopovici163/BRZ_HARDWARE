chips.prt
